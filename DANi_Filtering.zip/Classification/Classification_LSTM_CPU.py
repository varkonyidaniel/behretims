from keras.models import Sequential
from keras.layers import Dense, LSTM, Dropout
import numpy as np
import sys, os, h5py
from datetime import datetime
from sklearn.model_selection import KFold
from multiprocessing import Process, shared_memory
import time


def create_model(num_of_deep_layers: int, out_act: str, seq_len: int, optimizer: str, num_classes: int,
                 num_of_unit_input_layer: int, num_of_unit_hidden_layer: int, num_of_unit_out_layer: int,
                 droupout: float = 0.25) -> Sequential:
    # create model
    print(f"{datetime.now()} Creation of sequential model...!")
    model = Sequential()

    # input layer
    print(f"{datetime.now()} input LSTM Layer was added to the model!")
    model.add(LSTM(num_of_unit_input_layer, input_shape=(seq_len, 1), return_sequences=True))

    # deep layers
    print(f"{datetime.now()} Deep LSTM layer(s) were added to the model!")
    for idx in range(num_of_deep_layers):
        model.add(LSTM(num_of_unit_hidden_layer, return_sequences=True))

    # out layers
    print(f"{datetime.now()} Out LSTM layer were added to the model!")
    model.add(LSTM(num_of_unit_out_layer))

    model.add(Dropout(droupout))

    print(f"{datetime.now()} Dense (out) layer was added to the model!")
    model.add(Dense(num_classes, activation=out_act))

    print(f"{datetime.now()} Compiling model STARTS! ")
    model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    # model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])

    print(f"{datetime.now()} Compiling model ENDS!")

    print(f"{datetime.now()} Creation of sequential model... DONE!")

    return model


def perform_training(X, id, tr_idxs, ts_idxs, num_of_deep_layers, out_act, seq_len, optimizer,
                     num_classes, n_unit_input, n_unit_hidden, n_unit_out, droupout, batch_size, epochs):
    model = create_model(num_of_deep_layers=num_of_deep_layers, out_act=out_act, seq_len=seq_len,
                         optimizer=optimizer, num_classes=num_classes, num_of_unit_input_layer=n_unit_input,
                         num_of_unit_hidden_layer=n_unit_hidden, num_of_unit_out_layer=n_unit_out, droupout=droupout)






    print(f'{datetime.now()} Training for fold {id} ... STARTS!', flush=True)
    hist = model.fit(x=X[tr_idxs], y=y[tr_idxs], epochs=epochs, verbose=2, batch_size=batch_size,
                     validation_data=(X[ts_idxs], y[ts_idxs]), validation_batch_size=batch_size)
    print(f'{datetime.now()} Training for fold {id} ... ENDS!', flush=True)

    print(f"Fold {id} validation accuracy: {hist.history['val_accuracy']}")
    print(f"Fold {id} train accuracy: {hist.history['accuracy']}")


def run_scenario(X, num_of_deep_layers, out_act, seq_len, optimizer, num_classes,
                 n_unit_input, n_unit_hidden, n_unit_out, droupout, batch_size, epochs, n_folds):
    processes = []
    i = 0
    for tr_idxs, ts_idxs, in KFold(n_splits=n_folds).split(X, y):
        _process = Process(target=perform_training, args=(
            X, i, tr_idxs, ts_idxs, num_of_deep_layers, out_act, seq_len, optimizer,
            num_classes, n_unit_input, n_unit_hidden, n_unit_out, droupout, batch_size, epochs))
        processes.append(_process)
        i = i + 1
        _process.start()
    for _process in processes:
        _process.join()

if __name__ == "__main__":

    if len(sys.argv) < 4:
        print('Missing argument: \n'
              '1-number of wav file processed\n'
              '2-feature name\n'
              '3-node id\n'    
              '4-out activation\n'
              '5-optimizer\n'
              f'number of received parameters: {len(sys.argv)}')
        sys.exit(1)

    max_id = int(sys.argv[1])           # NUmber of processed WAV files, referes to sourcefile
    feature_name = sys.argv[2]          # Feature type name, referes to sourcefile
    node=sys.argv[3]
    out_act=node=sys.argv[4]
    optimizer=node=sys.argv[5]

    # Create full path from filename
    par_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    path = f"{par_dir}/DANI_FILTERING_1/Data/FE_data/"
    #path = f"{par_dir}/Data/FE_data/"
    data_filename = f"data_{feature_name}_{max_id}.h5"
    label_filename = f"label_{max_id}.h5"

    if not os.path.exists(path + data_filename):
        print(f'Not valid path! {path + data_filename}')
        sys.exit(2)

    if not os.path.exists(path + label_filename):
        print(f'Not valid path! {path + label_filename}')
        sys.exit(3)

    try:

        # DATA FILE
        print(f"{datetime.now()} Read from .../{data_filename} STARTS!", flush=True)

        file_size_in_bytes = os.stat(path + data_filename).st_size
        X = shared_memory.SharedMemory(create=True, size=int(file_size_in_bytes * 1.05))
        hf = h5py.File(path + data_filename, 'r')
        idx = 1
        for dataset_name in hf.keys():
            if idx == 1:
                X = np.asarray(hf.get(dataset_name))
                X = np.expand_dims(X, axis=0)
                idx=2
            else:
                X = np.append(X, np.expand_dims(hf.get(dataset_name), axis=0), axis=0)

        print(f"{datetime.now()} Read from .../{data_filename} ENDS!", flush=True)

        # LABEL FILE
        print(f"{datetime.now()} Read from .../{label_filename} STARTS!", flush=True)

        file_size_in_bytes = os.stat(path + label_filename).st_size
        y = shared_memory.SharedMemory(create=True, size=int(file_size_in_bytes * 1.05))
        #hf = h5py.File(path + label_filename, 'r')
        idx = 1
        for label_name in hf.keys():
            if idx == 1:
                y = np.asarray(hf.get(label_name))
                y = np.expand_dims(y, axis=0)
                idx=2
            else:
                y = np.append(y, np.expand_dims(hf.get(label_name), axis=0), axis=0)

        print(f"{datetime.now()} Read from .../{label_filename} ENDS!", flush=True)

        print(f"memsize of data: {X.nbytes} bytes", flush=True)
        print(f"memsize of labels: {y.nbytes} bytes", flush=True)

        num_classes = len(np.unique(y))

        print(X.shape)
        if feature_name == "TimeSeries":
            seq_len = X.shape[1]  # TImeseries: X.shape[1], other X.shape[2]
            X = np.reshape(X, (X.shape[0], X.shape[1], 1))  # TImeseries: X., 0, 1, 1, other X.0,2,1
        else:
            seq_len = X.shape[2]
            X = np.reshape(X, (X.shape[0], X.shape[2], 1))

        # ==============================================================
        # MULTIPLE SCENARIOS SHOULD COME AFTER DATA READING IN ORDER ONE BY ONE FROM HERE!!!!
        # ==============================================================

        num_of_deep_layers = 3
        droupout = 0.25
        batch_size = 100
        epochs = 500
        n_folds = 5
        n_repeats = 1

        #for out_act in ['sigmoid', 'softmax']:
            #for optimizer in ['sgd', 'adam']:
        for n_unit in [4, 8, 16, 32, 64, 128, 256]:
            print(f" ========== Parameters of Scenario: ========== ")
            print(f"number of deep layers: {num_of_deep_layers}\n"
                          f"out activation: {out_act}\n"
                          f"optimizer: {optimizer}\n"
                          f"number of units INPUT/HIDDEN/OUT layer: {n_unit}\n"
                          f"dropout: {droupout}\n"
                          f"batch size: {batch_size}\n"
                          f"epochs: {epochs}\n"                              
                          f"number of folds: {n_folds}\n"
                          f"Node: {node}")
            print(f" ========================================== ", flush=True)

            print(f"{datetime.now()} Scenario STARTS!", flush=True)

            run_scenario(X, num_of_deep_layers, out_act, seq_len, optimizer, num_classes,
                                    n_unit, n_unit, n_unit, droupout, batch_size, epochs, n_folds)

            print(f"{datetime.now()} Scenario ENDS!", flush=True)
            print(f"{datetime.now()} Sleeping 10 seconds", flush=True)
            time.sleep(10)

    finally:
        del X
    print('Done')
