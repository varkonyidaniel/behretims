from keras.models import Sequential
from keras.layers import Dense, Flatten, Conv2D, MaxPooling2D, SpatialDropout2D
import numpy as cp
import sys, os, h5py
from datetime import datetime
from sklearn.model_selection import KFold
import time
#import vaex
import gc

currentdir = os.path.dirname(os.path.realpath(__file__))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import Enum.Enum_types as et


def create_model(num_of_deep_layers: int, deep_act: str, out_act: str, input_shape: tuple,
                 kernel_size: int, optimizer: str, num_classes: int, strides: int,
                 num_of_unit_input_layer: int, num_of_unit_hidden_layer: int,
                 num_of_unit_out_layer: int, droupout: float = 0.25) -> Sequential:
    # create model
    print(f"{datetime.now()} Creation of sequential model...!", flush=True)
    model = Sequential()

    # input layer
    print(f"{datetime.now()} Input Conv.layer and Max pooling layer was added to the model!")
    model.add(
        Conv2D(filters=num_of_unit_input_layer, kernel_size=(kernel_size, kernel_size), #strides=(strides, strides),
               padding='same',
               activation=deep_act, input_shape=input_shape))
    model.add(MaxPooling2D(pool_size=(2, 2), strides=(strides, strides)))

    # deep layers
    print(f"{datetime.now()} Deep Conv.layer and Max pooling layer was added to the model!")
    for idx in range(num_of_deep_layers):
        model.add(Conv2D(num_of_unit_hidden_layer, kernel_size=(kernel_size, kernel_size), activation=deep_act))
        model.add(MaxPooling2D(pool_size=(2, 2), strides=(strides, strides)))

    model.add(SpatialDropout2D(droupout))

    # Flatten serves as a connection between the convolution and dense layers.
    print(f"{datetime.now()} Flattening layer was added to the model!")
    model.add(Flatten())

    # output layer (weighted sum + act function)
    print(f"{datetime.now()} Dense last layer was added to the model!")
    model.add(Dense(num_of_unit_out_layer, activation=deep_act))

    print(f"{datetime.now()} Dense (out) layer was added to the model!")
    model.add(Dense(num_classes, activation=out_act))

    print(f"{datetime.now()} Compiling model STARTS! ")
    model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    print(f"{datetime.now()} Compiling model ENDS!")

    print(f"{datetime.now()} Creation of sequential model... DONE!", flush=True)

    return model

def perform_training(X, y, id, tr_idxs, ts_idxs, num_of_deep_layers, deep_act, out_act, d_s, kernel_size, optimizer,
                     n_classes, strides, n_unit_input, n_unit_hidden, n_unit_out, droupout, batch_size, epochs):

    model = create_model(num_of_deep_layers=num_of_deep_layers, deep_act=deep_act, out_act=out_act,
                         input_shape=d_s, kernel_size=kernel_size, optimizer=optimizer,
                         num_classes=n_classes, strides=strides, num_of_unit_input_layer=n_unit_input,
                         num_of_unit_hidden_layer=n_unit_hidden, num_of_unit_out_layer=n_unit_out, droupout=droupout)

    print(f'{datetime.now()} Training for fold {id} ... STARTS!', flush=True)
    hist = model.fit(x=X[tr_idxs], y=y[tr_idxs], epochs=epochs, verbose=0, batch_size=batch_size,
                     validation_data=(X[ts_idxs], y[ts_idxs]), validation_batch_size=batch_size)

    del model

    print(f'{datetime.now()} Training for fold {id} ... ENDS!', flush=True)

    print(f"Fold {id} validation accuracy: {hist.history['val_accuracy']}")
    print(f"Fold {id} train accuracy: {hist.history['accuracy']}")
    del hist
    gc.collect()

def parameter_check_and_handling(argv:list):
    if len(sys.argv) <= 4:
        print('Missing argument: \n'
              '1-number of wav file processed\n'
              '2-feature name\n'
              '3-filter name\n'
              '4-node id\n'              
              f'number of received parameters: {len(sys.argv)}')
        sys.exit(1)

    try:
        n_processed_file = int(argv[1])
    except ValueError:
        print(f"unable to cast 1st parameter: {argv[1]} to integer as number of processed files. ERROR")
        exit(1)

    if argv[2] not in et.Feature_type._value2member_map_:
        print(f"{argv[2]} not recognised as a valid feature type. ERROR")
        sys.exit(1)
    else:
        feature_type = et.Feature_type(argv[2])

    if argv[3] not in et.filtering_type._value2member_map_:
        print(et.filtering_type._value2member_map_)
        print(f"{argv[3]} not recognised as a valid filter type. ERROR")
        sys.exit(1)
    else:
        filter_type = et.filtering_type(argv[3])

        node_id = argv[4]

    return n_processed_file, feature_type, filter_type, node_id

if __name__ == "__main__":

    n_files_processed, feature_type, filter_type, node = parameter_check_and_handling(sys.argv)

    parent_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    path=f"{parent_dir}/DANI_FILTERING_1/Data/FE_data/"
    #path = f"{parent_dir}/Data/FE_data/"
    data_filename = f"data_{feature_type.name}_{filter_type.name}_{n_files_processed}.h5"
    label_filename = f"label_{n_files_processed}.h5"

    if not os.path.exists(path + data_filename):
        print(f'Not valid path! {path + data_filename}')
        sys.exit(2)

    if not os.path.exists(path + label_filename):
        print(f'Not valid path! {path + label_filename}')
        sys.exit(3)

    try:

        #------------
        # DATA FILE
        #------------

        print(f"{datetime.now()} Read from .../{data_filename} STARTS!", flush=True)


#        h5file_data = vaex.open(path=path + data_filename)
        h5file_data = h5py.File(path + data_filename, 'r')
        idx = 1
        for dataset_name in h5file_data.keys():
            if idx == 1:
                X =  cp.expand_dims(cp.asarray(h5file_data.get(dataset_name)), axis=0)
                idx=2
            else:
                X = cp.append(X, cp.expand_dims(cp.asarray(h5file_data.get(dataset_name)), axis=0), axis=0)

        print(f"{datetime.now()} Read from .../{data_filename} ENDS!", flush=True)

        #------------
        # LABEL FILE
        #------------

        print(f"{datetime.now()} Read from .../{label_filename} STARTS!", flush=True)

        h5file_label = h5py.File(path + label_filename, 'r')
        idx = 1
        for label_name in h5file_label.keys():
            if idx == 1:
                y = cp.expand_dims(cp.asarray(h5file_label.get(label_name)), axis=0)
                idx=2
            else:
                y = cp.append(y, cp.expand_dims(cp.asarray(h5file_label.get(label_name)), axis=0), axis=0)

        print(f"{datetime.now()} Read from .../{label_filename} ENDS!", flush=True)

        print(f"memsize of data: {X.nbytes} bytes", flush=True)
        print(f"memsize of labels: {y.nbytes} bytes", flush=True)

        n_classes = len(cp.unique(y))
        d_s = (X.shape[1], X.shape[2], 1)
        X = cp.expand_dims(X, axis=3)

        # ==============================================================
        # MULTIPLE SCENARIOS SHOULD COME AFTER DATA READING IN ORDER ONE BY ONE FROM HERE!!!!
        # ==============================================================

        num_of_deep_layers=1 #3 
        epochs = 100
        n_folds = 10  # 10
        droupout = 0.25
        kernel_size = 3
        strides = 2
        batch_size=250  # 1250 MFCC_DELTA
        sleeping_time_s=1

        for n_unit in [8, 12, 16, 20, 25, 50]:
            for out_act in ['sigmoid', 'softmax']:
                for optimizer in ['sgd','adam']:
                    for deep_act in ['relu','sigmoid']:
                        print(f" ========== Parameters of Scenario: ========== ")
                        print(f"number of units INPUT/HIDDEN/OUT layer: {n_unit}\n"
                              f"out activation: {out_act}\n"
                              f"deep activation: {deep_act}\n"
                              f"optimizer: {optimizer}\n"
                              f"number of deep layers: {num_of_deep_layers}\n"
                              f"epochs: {epochs}\n"
                              f"number of folds: {n_folds}\n"
                              f"dropout: {droupout}")
                        print(f" ========================================== ", flush=True)

                        print(f"{datetime.now()} Scenario STARTS!", flush=True)

                        # RUN SCENARIO
                        i = 0

                        for tr_idxs, ts_idxs, in KFold(n_splits=n_folds).split(X, y):

                            # sequential execution
                            perform_training(X, y, i, tr_idxs, ts_idxs, num_of_deep_layers,
                                             deep_act, out_act, d_s, kernel_size, optimizer, n_classes,
                                             strides, n_unit, n_unit, n_unit, droupout,
                                             batch_size, epochs)
                            i = i + 1


                        print(f"{datetime.now()} Scenario ENDS!", flush=True)
                        print(f"{datetime.now()} Sleeping {sleeping_time_s} seconds", flush=True)
                        time.sleep(sleeping_time_s)
    finally:
        print('Terminated')
