import sys, os, glob
import numpy as np
import Enum.Enum_types as et
from scipy.io import wavfile
from Feature_extraction import Feature_Extraction as fe
from Filtering import filtering as filt
import Outputs.Data_Writter as dw


def parameter_check_and_handling(argv:list):
    if len(argv) <= 3:      #sys.argv[0] is always the file exacuted by python
        print("Expected parameters: \n "
              "1 - number of features (DIM 1), \n"
              "2 - hop_length, \n"
              "3 - number of max file to read\n"
              f"number of received parameters: {len(argv)}")
        sys.exit(1)

    try:
        n_feature = int(argv[1])
    except ValueError:
        print(f"unable to cast 1st parameter: {argv[1]} to integer as number of features. ERROR")
        exit(1)

    try:
        hop_length = int(argv[2])
    except ValueError:
        print(f"unable to cast 2nd parameter: {argv[2]} to integer as hop length. ERROR")
        exit(1)

    try:
        max_id = int(argv[3])
    except ValueError:
        print(f"unable to cast 3rd parameter: {argv[3]} to integer as max number of file to process. ERROR")
        exit(1)

    return n_feature, hop_length, max_id


def check_directories(parent_dir:str, source_dir:str, target_dir:str):
    if not os.path.isdir(parent_dir+source_dir):
        print(f'Missing source directory: {parent_dir+source_dir}')
        sys.exit(1)

    if not os.path.isdir(parent_dir+target_dir):
        os.mkdir(parent_dir+target_dir)
        print(f'Missing target directory. Creating: {target_dir}')


if __name__ == "__main__":

    n_features, hop_length, max_id = parameter_check_and_handling(sys.argv)

    source_dir = "/DANI_FILTERING_1/Data/WAV_data"
    target_dir = "/DANI_FILTERING_1/Data/FE_data"
    #source_dir = "/Data/WAV_data"
    #target_dir = "/Data/FE_data"
    parent_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    file_count = 0

    check_directories(parent_dir,source_dir, target_dir)

    os.chdir(parent_dir+source_dir)

    #get current hive ids, change labels to number 0,1,....
    ids=[]
    for file in glob.glob("*.wav"):
        ids.append(int(file.split('-')[-1].split('.')[-2]))
    old_labels = np.unique(ids)

    # PROCESSING OF WAV files in order
    for file_name in glob.glob("*.wav"):
        if file_count == max_id:
            sys.exit(2)

        cur_flag = int(file_name.split('-')[-1].split('.')[-2])
        sr,wav_data = wavfile.read(f'{file_name}')
        wav_data = wav_data.astype(float)

        # new flag is the index of old flag
        new_flag = np.where(old_labels==cur_flag)[0]
        i=0
        try:
            for feat_type in [et.Feature_type.CHROMA,et.Feature_type.MFCC_DELTA]:

                feature_set = fe.Fit(data=wav_data, type=feat_type, hop_length=hop_length,
                                     n_features=n_features, sampling_rate=sr)

                #Median
                filt_feature_set = filt.Fit(data=feature_set,type=et.filtering_type.MEDIAN,sampling_rate=sr,
                                            separation_logic=et.separation_type.BY_FREQ_SLICES.value,
                                            cutoff=(0,1000),order=1)
                #LoG
                filt_feature_set = filt.Fit(data=filt_feature_set,type=et.filtering_type.GAUSSIAN_LAPLACE,
                                            sampling_rate=sr,separation_logic=et.separation_type.BY_FREQ_SLICES.value,
                                            cutoff=(0,1000),order=1)

                dw.write_data_to_h5(parent_dir + target_dir, feat_type.name, "median_LoG",
                                    max_id, filt_feature_set, file_name, file_count)

                i=i+1

        except Exception as inst:
            print(f"==============  ERROR: {file}  ==============")
            print(inst)  # __str__ allows args to be printed directly,
            print(f"=============================================")

        #dw.write_label_to_h5(parent_dir + target_dir,max_id,new_flag,file_name,file_count)

        file_count = file_count + 1

    sys.exit(0)
