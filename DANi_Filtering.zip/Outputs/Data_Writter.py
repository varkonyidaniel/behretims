import csv, time
import numpy as np
import h5py


def write_data(dir:str,fe:str,max_idx:int,Data:np.ndarray,file_name:str, id):

    with open(f"{dir}/out_{fe}_{max_idx}.csv", mode='a') as out_file:
        _writer = csv.writer(out_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        _writer.writerow(Data)

    print(f"{id}. Appending file: {file_name} ... to {fe} output...DONE!", flush=True)

def write_data_to_h5(dir:str,feature:str,filter:str,max_idx:int,Data:np.ndarray,file_name:str, id:int):

    hf = h5py.File(f"{dir}/data_{feature}_{filter}_{max_idx}.h5", 'a')
    hf.create_dataset(f"dataset_{id}", data=Data)
    hf.close()
    print(f"{id}. Appending file: {file_name} ... to {feature} {filter} output...DONE!", flush=True)

def write_label_to_h5(dir:str,max_idx:int,label:int, file_name:str, id:int):

    hf = h5py.File(f"{dir}/label_{max_idx}.h5", 'a')
    hf.create_dataset(f"label_{id}", data=label)
    hf.close()
    print(f"{id}. Appending label of: {file_name} ... to label output...DONE!", flush=True)
