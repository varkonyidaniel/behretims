import matplotlib.pyplot as plt
import numpy as np
import os
from matplotlib import rcParams

def read_csv_file(filename: str):
    file = open(filename, 'r')
    idx=1
    tmp, val_acc, params = [], [],[]
    param_line = False
    for line in file:

        if line == " ========================================== \n":
            param_line = False

        if param_line:
            params.append(line.split(":")[1][1:-1])

        if line[0:10]  == "validation":
            #val_acc.append(np.asarray(line.replace("]",'').replace("[",'').replace("\\",'')[21:-1].split(", ")).astype(float))
            tmp.extend(line[23:-3].split("], ["))
            # Each list is the result of 1 fold

            for i in range(len(tmp)):
                val_acc.append(np.asarray(tmp[i].split(", ")).astype(float))

        if line == " ========== Received parameters: ========== \n":
            param_line = True

        if line [:9] == "Read from":
            params.append(line.split("/out_")[1][:-14])

        idx=idx+1
    return val_acc,params

def visualize_result(acc_history:list, params:list, filename:str):



    fig, axs = plt.subplots(5, 2,constrained_layout=True)
    fig.suptitle(f"{filename} units: {params[5]}, optimizer: {params[8]}, feature: {params[9].split('/')[-1][:-10]} ", fontsize=24)


    fig.set_size_inches(15, 12)

    for i in range(10):
        #axs[int(i/2),int(i%2)].plot(acc_history[i*500:(i+1)*500-1])

        axs[int(i / 2), int(i % 2)].plot(acc_history[i])

    #plt.subplots_adjust(top=0.2,wspace=0.2,hspace=0.2)


    plt.show()

if __name__ == "__main__":

    fe = "bf"

    if fe == "mfcc":
        nums = [649,653,657,1231,1235,1239,1243,1247,1258]
    elif fe == "mfcc_delta":
        nums = [650, 654, 1232, 1236, 1240, 1244, 1248, 1259]
    elif fe == "stft":
        #nums = [1233, 1237, 1241, 1245, 1249, 1260]
        nums = [1233, 1245]
    elif fe == "bf":
        nums = [652,1234, 1238, 1246]
    else:
        print(f"wrong feature name: {fe}")
        exit(1)

    files = []

    for i in nums:
        files.append(f"slurm-{i}_{fe}.out")

    for file in files:
        val_acc, params = read_csv_file("/Users/varkonyidaniel/PycharmProjects/Simple_Heuritic_Filtering/LOGS/" + file)
        visualize_result(val_acc,params, file)

    print("Done")
