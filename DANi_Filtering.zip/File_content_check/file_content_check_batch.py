import File_content_check.file_content_check as fcc
import sys, os, glob

if __name__ == '__main__':

    source_dir = "/DANI_FILTERING_1/Data/FE_data"
    par_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    os.chdir(par_dir + source_dir)

    for file in glob.glob("*.csv"):
        feature_name = file[4:].split('_')[0]

        # CHECK FILE EXISTENCE
        if not os.path.exists(file):
            print(f"File dosen't exist: {file}")
            sys.exit(2)

        #check_matrix_data(file)
        fcc.check_ts_data(file)
