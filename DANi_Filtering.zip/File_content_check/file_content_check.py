import numpy as np


def check_ts_data(fn: str):

    file = open(fn, 'r')
    labels = []

    for idx, line in enumerate(file):
        sp_l = line.split(',')
        labels.append(int(complex(sp_l[0]).real))

        length = (int(complex(sp_l[1]).real),int(complex(sp_l[2]).real))
        data = sp_l[3:]
        l_dim = 2

        if len(sp_l) != 3 + len(data): # 1st label, 2nd and 3rd dim, 4th... data
            print(f"length of dataline is not matching with expected value 1 + {l_dim} + {len(data)}!")
        if idx == 0:
            ref_len = length
        else:
            if ref_len != length:
                print(f"Error in data in file {fn}, line: {idx}: ref_len: {ref_len}, curr_len: {length}")

    unique, counts = np.unique(np.asarray(labels),return_counts=True)
    print(f"{fn}: unique values are: {unique}, counts: {counts}, num of samples: {idx+1}, dim of samples: {length}")
    file.close()
